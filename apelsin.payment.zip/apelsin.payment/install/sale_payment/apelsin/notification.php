<?php
	require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/bx_root.php");
	require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

	CModule::IncludeModule('sale');

	header('Content-type: application/json');

	include(dirname(__FILE__) . "/api/ApelsinApi.php");

	$api = new ApelsinApi();
	$api->setInputArray(file_get_contents("php://input"));
	$api->parseRequest();
?>