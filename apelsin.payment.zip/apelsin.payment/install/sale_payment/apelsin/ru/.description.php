<?
global $MESS;
$MESS["APELSIN_MERCHANT"] = "ID поставщика";
$MESS["APELSIN_MERCHANT_DEF"] = "Идентификатор мерчанта";

$MESS["APELSIN_SERVER_URL"] = "Url для APELSIN";

$MESS["APELSIN_CHECKOUT_URL"] = "Введите URL-адрес шлюза";


$MESS["APELSIN_TEST_MODE"] = "Enable test mode";

$MESS["SITE_BACK_URL"] = "Вернуться после оплаты на";
$MESS["APELSIN_END_POINT_URL"] = "End Point Url";
?>