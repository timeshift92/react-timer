<?php
$MESS["APELSIN_MODULE_NAME"] = "apelsin.digital";
$MESS["APELSIN_MODULE_DESC"] = "apelsin.digital платёжный модуль для Bitrix CMS";
?>