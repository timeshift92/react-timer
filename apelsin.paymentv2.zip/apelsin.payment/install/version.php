<?
$arModuleVersion = array(

	"VERSION" => "1.0.1 (utf-8)",
	"VERSION_DATE" => "2020-04-20"
);
?>
