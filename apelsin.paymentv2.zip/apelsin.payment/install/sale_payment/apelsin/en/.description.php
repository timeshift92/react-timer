<?
global $MESS;
$MESS["APELSIN_MERCHANT"] = "Merchant Id";
$MESS["APELSIN_MERCHANT_DEF"] = "Merchant Id";

$MESS["APELSIN_SERVER_URL"] = "Url for APELSIN";

$MESS["APELSIN_CHECKOUT_URL"] = "URL gateway";

$MESS["APELSIN_TEST_MODE"] = "Enable test mode";

$MESS["SITE_BACK_URL"] = "Redirection URL";
$MESS["APELSIN_END_POINT_URL"] = "End Point Url";
?>