<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();?><?

include(GetLangFileName(dirname(__FILE__) . "/", "/.description.php"));

$psTitle = "Apelsin";
$psDescription = "<a href=\"https://apelsin.digital\" target=\"_blank\">https://apelsin.digital</a>";


$arPSCorrespondence = array( 



	'ENDPOINT_URL' => array(
		'NAME'  => "End Point Url",
		'DESCR' => GetMessage('APELSIN_END_POINT_URL'),
		'SORT'  => 1007,
		'VALUE' => '',
		'TYPE'  => 'VALUE',
		'DEFAULT' => array(
				'PROVIDER_VALUE' =>'http://' . $_SERVER['SERVER_NAME'] . '/personal/order/notification.php',
				'PROVIDER_KEY' => 'VALUE',
			)
	),

	'BACK_AFTER_PAYMENT_URL' => array(
		'NAME'  => "REDIRECT_URL",
		'DESCR' => GetMessage('SITE_BACK_URL'),
		'SORT'  => 1007,
		'VALUE' => '',
		'TYPE'  => 'VALUE',
		'DEFAULT' => array(
				'PROVIDER_VALUE' => 'http://' . $_SERVER['SERVER_NAME'] . '/personal/orders/',
				'PROVIDER_KEY' => 'VALUE',
			)
	),

	'TEST_MODE' => array(
		'NAME'  => GetMessage('APELSIN_TEST_MODE'),
		'DESCR' => GetMessage('APELSIN_TEST_MODE'),
		'SORT'  => 1003,
		'INPUT' => array(
				'TYPE' => 'Y/N'
			)
	),	
	'CHECKOUT_URL' => array(
		'NAME'  => 'CHECKOUT_URL',
		'DESCR' => GetMessage('APELSIN_CHECKOUT_URL'),
		'SORT'  => 1005,
		'VALUE' => '',
		'TYPE'  => 'VALUE',
		'DEFAULT' => array(
				'PROVIDER_VALUE' => 'https://oplata.kapitalbank.uz',
				'PROVIDER_KEY' => 'VALUE',
			)
	),

	'APELSIN_URL' => array(
		'NAME'  => "URL for Apelsin",
		'DESCR' => GetMessage('APELSIN_SERVER_URL'),
		'SORT'  => 1004,
		'VALUE' => '',
		'TYPE'  => 'VALUE',
		'DEFAULT' => array(
				'PROVIDER_VALUE' => "https://apelsin.digital",
				'PROVIDER_KEY' => 'VALUE',
			)
	),
		

	'P_MERCHANT'  => array(
		'NAME'  => "CASH",
		'DESCR' => GetMessage('APELSIN_MERCHANT_DEF'),
		'SORT'  => 1000,
		'VALUE' => '',
		'TYPE'  => 'VALUE'
	)
);
?>