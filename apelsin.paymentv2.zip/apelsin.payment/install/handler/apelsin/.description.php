<?php
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/apelsin.payment/install/sale_payment/apelsin/.description.php");
?>