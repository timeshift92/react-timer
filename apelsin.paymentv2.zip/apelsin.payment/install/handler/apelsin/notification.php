<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/apelsin.payment/install/sale_payment/apelsin/notification.php");
?>