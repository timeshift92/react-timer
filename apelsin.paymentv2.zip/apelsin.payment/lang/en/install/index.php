<?php
$MESS["APELSIN_MODULE_NAME"] = "apelsin.digital";
$MESS["APELSIN_MODULE_DESC"] = "apelsin.digital payment module for Bitrix CMS";
?>