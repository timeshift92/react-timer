﻿<?php

$MESS['CLICK_UZ_NAME']               = 'Click Uzbekistan';
$MESS['CLICK_UZ_MODULE_NAME']        = 'Click Uzbekistan';
$MESS['CLICK_UZ_MODULE_DESCRIPTION'] = <<<TEXT
The CLICK system is a mobile banking system that allows you to pay by mobile phone for
services of mobile operators, Internet providers and other companies; pay for goods in traditional and online stores;
transfer money from card to card, and much more ..
TEXT;
$MESS['CLICK_UZ_PARTNER_NAME']       = 'CLICK Uzbekistan';
$MESS['CLICK_UZ_PARTNER_URI']        = 'https://click.uz/';