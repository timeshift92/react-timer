<?php

$MESS['CLICK_UZ_NAME']             = 'CLICK Узбекистан';
$MESS['CLICK_UZ_MERCHANT_ID']      = 'Номер поставщика (MERCHANT_ID)';
$MESS['CLICK_UZ_MERCHANT_USER_ID'] = 'Номер пользователя поставщика (MERCHANT_USER_ID)';
$MESS['CLICK_UZ_SERVICE_ID']       = 'Номер сервиса (SERVICE_ID)';
$MESS['CLICK_UZ_SECRET_KEY']       = 'Секретный ключ (SECRET_KEY)';
$MESS['CLICK_UZ_USE_POPUP']        = 'Использовать всплывающую форму оплаты на страницах магазина.';
$MESS['CLICK_UZ_PREPARE_URL']      = 'Адрес проверки (prepare url)';
$MESS['CLICK_UZ_COMPLETE_URL']     = 'Адрес результата (complete url)';
