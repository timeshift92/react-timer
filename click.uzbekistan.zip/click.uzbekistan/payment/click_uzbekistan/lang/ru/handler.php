﻿<?php

$MESS['ERROR_USER_DOES_NOT_EXISTS']       = 'Не найдет пользователь/заказ';
$MESS['ERROR_IN_REQUEST_FROM_CLICK']      = 'Ошибка в запросе от CLICK';
$MESS['ERROR_SIGN_CHECK']                 = 'ОШИБКА ПРОВЕРКИ ПОДПИСИ!';
$MESS['ERROR_ALREADY_PAID']               = 'Транзакция ранее была подтверждена';
$MESS['ERROR_INCORRECT_AMOUNT']           = 'Неверная сумма оплаты';
$MESS['ERROR_UPDATE_FAILED']              = 'Ошибка при изменении данных';
$MESS['ERROR_TRANSACTION_DOES_NOT_EXIST'] = 'Не найдена транзакция';