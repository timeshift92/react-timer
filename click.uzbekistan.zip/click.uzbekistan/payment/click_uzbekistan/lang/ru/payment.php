﻿<?php

$MESS['SALE_HANDLERS_CLICK_UZ_DESCRIPTION']    = <<<HTML
Услугу предоставляет сервис онлайн-платежей <b>&laquo;CLICK Узбекистан&raquo;</b>.<br /><br />Сумма к оплате по счету: 
HTML;
$MESS['SALE_HANDLERS_CLICK_UZ_WARNING_RETURN'] = <<<HTML
<b>Обратите внимание:</b> если вы откажетесь от покупки, для возврата денег вам придется обратиться в магазин.
HTML;
$MESS['SALE_HANDLERS_CLICK_UZ_REDIRECT']       = 'вы будете перенаправлены на страницу оплаты';
$MESS['SALE_HANDLERS_CLICK_UZ_BUTTON_PAID']    = 'Оплатить через CLICK';
$MESS['SALE_HANDLERS_CLICK_UZ_REDIRECT_MESS']  = 'Вы будете перенаправлены на страницу оплаты';
