﻿<?php


$MESS['SALE_HANDLERS_CLICK_UZ_DESCRIPTION']    = <<<HTML
The service provides online payment service <b>&laquo;CLICK Uzbekistan&raquo;</b>.<br /><br />Sum to pay: 
HTML;
$MESS['SALE_HANDLERS_CLICK_UZ_WARNING_RETURN'] = <<<HTML
<b>Notice:</b> if you refuse a purchase, you will have to contact the store for a refund.
HTML;
$MESS['SALE_HANDLERS_CLICK_UZ_REDIRECT']       = 'you will be redirected to the payment page';
$MESS['SALE_HANDLERS_CLICK_UZ_BUTTON_PAID']    = 'Pay with CLICK';
$MESS['SALE_HANDLERS_CLICK_UZ_REDIRECT_MESS']  = 'You will be redirected to the payment page';