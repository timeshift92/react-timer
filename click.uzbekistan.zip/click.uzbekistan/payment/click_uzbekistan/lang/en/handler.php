﻿<?php

$MESS['ERROR_USER_DOES_NOT_EXISTS']       = 'User does not exist';
$MESS['ERROR_IN_REQUEST_FROM_CLICK']      = 'Error in request from click';
$MESS['ERROR_SIGN_CHECK']                 = 'SIGN CHECK FAILED!';
$MESS['ERROR_ALREADY_PAID']               = 'Already paid';
$MESS['ERROR_INCORRECT_AMOUNT']           = 'Incorrect payment amount';
$MESS['ERROR_UPDATE_FAILED']              = 'Update failed';
$MESS['ERROR_TRANSACTION_DOES_NOT_EXIST'] = 'Transaction does not exist';
