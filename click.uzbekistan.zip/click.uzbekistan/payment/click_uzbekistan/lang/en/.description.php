<?php

$MESS['CLICK_UZ_NAME']             = 'CLICK Uzbekistan';
$MESS['CLICK_UZ_MERCHANT_ID']      = 'Merchant ID';
$MESS['CLICK_UZ_MERCHANT_USER_ID'] = 'Merchant user ID';
$MESS['CLICK_UZ_SERVICE_ID']       = 'Service ID';
$MESS['CLICK_UZ_SECRET_KEY']       = 'Secret key';
$MESS['CLICK_UZ_USE_POPUP']        = 'Use popup payment form on shop pages.';
$MESS['CLICK_UZ_PREPARE_URL']      = 'Prepare url';
$MESS['CLICK_UZ_COMPLETE_URL']     = 'Complete url';

