﻿<?php

require $_SERVER["DOCUMENT_ROOT"] .'/bitrix/modules/click.uzbekistan/payment/click_uzbekistan/payment.php';
