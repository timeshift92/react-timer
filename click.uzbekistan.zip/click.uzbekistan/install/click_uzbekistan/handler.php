﻿<?php
require_once $_SERVER["DOCUMENT_ROOT"] . '/bitrix/modules/click.uzbekistan/payment/click_uzbekistan/handler.php';
