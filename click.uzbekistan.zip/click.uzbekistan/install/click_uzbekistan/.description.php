﻿<?php

require __DIR__.'/../../../../modules/click.uzbekistan/payment/click_uzbekistan/.description.php';
