﻿<?php

/** @var array $arModuleVersion Module version metadata. */
$arModuleVersion = [
    'VERSION'      => '0.0.3',
    'VERSION_DATE' => '2019-12-04 00:00',
];
